#!/bin/bash
apt update && apt install -y nginx && nohup /usr/sbin/nginx & 
