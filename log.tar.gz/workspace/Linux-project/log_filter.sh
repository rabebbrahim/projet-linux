#!/bin/bash
grep 'error' $1 && grep 'warning' $1 
