#!/bin/bash

docker exec -it linux1 /bin/bash

apt update

apt install nginx -y

