#!/bin/bash

cp html_root/index.html /var/www/html/
apt update 
apt install nginx
